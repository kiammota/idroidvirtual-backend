import { HttpClient } from "../http.js";
import { ResumoFinanceiro } from "../models/FinanceiroModel.js";

class FinanceiroServiceClass extends HttpClient {
  /**
   * Obtém o resumo financeiro do dia atual
   * GET /financeiro/hoje
   */
  async getHoje() {
    const response = await this.get("/financial/today");
    if (response.success && response.data) {
      response.data = new ResumoFinanceiro(response.data);
    }
    return response;
  }

  /**
   * Obtém o resumo financeiro do mês corrente
   * GET /financeiro/mes
   */
  async getMesAtual() {
    const response = await this.get("/financial/month");
    if (response.success && response.data) {
      response.data = new ResumoFinanceiro(response.data);
    }
    return response;
  }

  /**
   * Obtém o resumo financeiro por intervalo de datas
   * GET /financeiro/periodo?inicio=YYYY-MM-DD&fim=YYYY-MM-DD
   * @param {string} inicio - Data no formato YYYY-MM-DD
   * @param {string} fim - Data no formato YYYY-MM-DD
   */
  async getPorIntervalo(inicio, fim) {
    const params = new URLSearchParams({ inicio, fim }).toString();
    const response = await this.get(`/financial/period?${params}`);

    if (response.success && response.data) {
      response.data = new ResumoFinanceiro(response.data);
    }
    return response;
  }
}

/** Singleton */
export const FinanceiroService = new FinanceiroServiceClass();
export default FinanceiroService;